package com.LearnAutomationOnline;

import java.util.Arrays;
import java.util.Iterator;

public class RemoveNegativesFromList {

	public static void main(String[] args) {
		int arrlist1[] = {1,2,3,5-7,-8};
		int arrlist2[] = new int[6];
		for (int i = 0; i < arrlist1.length; i++) {
			if(arrlist1[i]>0)
			{
				System.out.println(arrlist1[i]);
				arrlist2[i]= arrlist1[i];
			}
		}
		System.out.println(Arrays.toString(arrlist2));
		
	}
}
