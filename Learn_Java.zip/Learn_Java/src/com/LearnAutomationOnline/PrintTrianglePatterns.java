package com.LearnAutomationOnline;

import java.util.Scanner;

public class PrintTrianglePatterns {

	//Print Triangle stars
	public void PrintTriangleStars() 
	{
		Scanner limit = new Scanner(System.in);
		System.out.println("How many lines to print stars ");
		int limitNo = limit.nextInt();  

		for(int row=0;row<=limitNo;row++)
		{
			for(int col=0;col<row;col++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}

	public void PrintTriangleNumbers()
	{
		int startingNumber=1;
		Scanner limit = new Scanner(System.in);
		System.out.println("How many lines to print numbers ");
		int limitNo = limit.nextInt();  

		for(int row=0;row<=limitNo;row++)
		{
			for(int col=0;col<row;col++)
			{
				System.out.print(startingNumber);
				startingNumber= startingNumber+1;
			}
			System.out.println();
		}

	}

	public static void main(String[] args) {

		PrintTrianglePatterns trianlgeObj= new PrintTrianglePatterns();
		//trianlgeObj.PrintTriangleStars();
		trianlgeObj.PrintTriangleNumbers();
	}

}
