package com.LearnAutomationOnline;

public class RemoveSpaceInString {

	public static void main(String[] args) {
		
		String str = "   HI WORLD   ";
		
		//str=str.strip();
		//str=str.stripLeading();
		//str=str.stripTrailing();
		System.out.println(str);
		
		
		//Using Regex pattern
		System.out.println(str.replaceAll("^[ \t]+|[ \t]+$",""));
	}
}
