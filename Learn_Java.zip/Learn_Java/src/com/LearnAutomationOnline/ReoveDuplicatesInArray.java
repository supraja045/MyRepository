package com.LearnAutomationOnline;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ReoveDuplicatesInArray {

	public static void main(String[] args) {
		/*Remove Duplicates from Sorted Array
		Input: nums = [0,0,1,1,1,2,2,3,3,4]*/

		List<Integer> list1=new ArrayList<Integer>(); 
		List<Integer> list2=new ArrayList<Integer>(); 
		list1.add(0);
		list1.add(0);
		list1.add(1);
		list1.add(1);
		list1.add(1);
		for(int i =0; i<list1.size();i++)
		{
			for(int j =i+1;j<list1.size();j++)
			{
				if(list1.get(i)==list1.get(j));
				{
					list2.add(list1.get(j));
				}
			}
		}
		System.out.println(list2);
	}
}
