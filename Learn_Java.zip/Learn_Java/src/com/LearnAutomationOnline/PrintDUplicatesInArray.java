package com.LearnAutomationOnline;
//
//public class PrintDUplicatesInArray {  
//    public static void main(String[] args) {   
import java.util.*;  
public class PrintDUplicatesInArray 
{
public static void main(String[] args) {

	 //Creating a List  
	 List<Integer> list=new ArrayList<Integer>();  
	 //Adding elements in the List  
	 list.add(1);  
	 list.add(2);  
	 list.add(3);  
	 list.add(4);  
	 list.add(1);  
	 list.add(2);  
	 list.add(3);  
	 list.add(8); 
	 List<Integer> opList=new ArrayList<Integer>();  
	 for (int i = 0; i < list.size(); i++) 
	 {
		for (int j = i+1; j < list.size(); j++) 
		{
			if(list.get(i)== list.get(j))
			{
				//System.out.println(list.get(i));
				list.remove(i);
				//opList.add(list.get(i));
			}
		}
	 }
	 System.out.println(list);
}
}
   
          
//        //Initialize array   
//        int [] arr = new int [] {1, 2, 3, 4, 2, 7, 8, 8, 3};   
//          
//        System.out.println("Duplicate elements in given array: ");  
//        //Searches for duplicate element  
//        for(int i = 0; i < arr.length; i++) {  
//            for(int j = i + 1; j < arr.length; j++) {  
//                if(arr[i] == arr[j])  
//                    System.out.println(arr[j]);  
//            }  
//        }  
//    /}  
//}  
