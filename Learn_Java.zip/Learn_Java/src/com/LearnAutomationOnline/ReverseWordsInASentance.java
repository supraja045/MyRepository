package com.LearnAutomationOnline;

public class ReverseWordsInASentance {

	public void ReverseWordsInSentance()
	{
	String given = "I Love India";
	
	String reversed= "";
	String[] givenArray= given.split(" ");
	
	for (int i=(givenArray.length-1);i>=0;i--)
	{
		reversed= reversed+" "+givenArray[i];
	}
	
	System.out.println(reversed);
	}
	
	
	public static void main(String[] args) {
		
		ReverseWordsInASentance ReverseObj= new ReverseWordsInASentance();
		
		ReverseObj.ReverseWordsInSentance();
		
	}
}
