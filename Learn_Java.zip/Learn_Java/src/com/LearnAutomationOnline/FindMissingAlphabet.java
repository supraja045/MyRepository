package com.LearnAutomationOnline;

import java.util.AbstractCollection;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class FindMissingAlphabet {


	public void FindingMissingAlphabet()
	{
		//Initializing the String
		String givenString= "supraja";

		//Converting the string to array
		givenString= givenString.toLowerCase();
		String[] myCharArray=givenString.split("");
		Arrays.sort(myCharArray);

		//Converting the alphabets to an array
		String alphabets="abcdefghijklmnopqrstuvwxyz";
		String[] lettersCharArray=alphabets.split("");
		Arrays.sort(lettersCharArray);

		//Creating two sort of sets to remove duplicates
		HashSet<String> myCharSet = new HashSet<>(Arrays.asList(myCharArray));
		HashSet<String> lettersCharSet = new HashSet<>(Arrays.asList(lettersCharArray));

		//Logic to remove the letters present inside the given string
		if(myCharSet.equals(lettersCharSet))
		{
			System.out.println("All the characters are present in the given string");
		}
		else
		{
			lettersCharSet.removeAll(myCharSet);
		}

		//Presenting the output
		System.out.println("Missing Alphabets in the string" + lettersCharSet);

	}

	public static void main(String[] args) 
	{
		FindMissingAlphabet myObj= new FindMissingAlphabet();
		myObj.FindingMissingAlphabet();
	}
}
