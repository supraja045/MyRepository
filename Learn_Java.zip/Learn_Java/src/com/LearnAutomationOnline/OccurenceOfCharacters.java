package com.LearnAutomationOnline;

import java.util.Iterator;

public class OccurenceOfCharacters 
{
public static void main(String[] args) {
	
	String input ="geeks for geeeeeks";
	int count=0;
	char givenChar='e';
	input.toCharArray();
	for (char string : input.toCharArray()) {
		if(givenChar==string)
		{
			count++;
		}
	
	}
	
	System.out.println("the count of "+givenChar +" is "+ count);
	}
}

//Write JavaScript code to apply 15% discount on wall clock product 
//and show both actual and discounted price on web page on click of a web button.