package com.LearnAutomationOnline;

import java.util.Scanner;

public class LengthOfString {


	public void FindLengthwithoutLen()
	{

		//String givenString ="thapovanam";
		
		Scanner limit = new Scanner(System.in);
		System.out.println("input the string to find out the length ");
		String givenString = limit.nextLine();  

		
		char[] charArray= givenString.toCharArray();
		
		int length =0;
		
		for (char c:charArray)
		{
			length++;
		}
		
		System.out.println("Length of the String "+ givenString +" is: " +length);
	}

	public static void main(String[] args) {

		LengthOfString lenObj= new LengthOfString();
		
		lenObj.FindLengthwithoutLen();
	
		
	}
}


