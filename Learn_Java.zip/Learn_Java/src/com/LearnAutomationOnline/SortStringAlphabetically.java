package com.LearnAutomationOnline;

import java.util.Arrays;

public class SortStringAlphabetically {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String input="wednesday";
		char charArray[] = input.toCharArray();
		Arrays.sort(charArray);
		System.out.println(new String(charArray));
	}

}


