package com.LearnAutomationOnline;

import java.util.Arrays;

public class SmallestNumberInArray {


	public void FindSmallestNoInArray()
	{

		int givenArray[] = {233,1342,2875,411111,56};
		//Logic
		System.out.println("Given array " +Arrays.toString(givenArray));
		int temp=0;

		for (int first=0;first<=givenArray.length;first++)
		{
			for (int second=first+1;second<=(givenArray.length-1);second++)
			{
				if(givenArray[first]>givenArray[second])
				{
					temp=givenArray[first];
					givenArray[first]=givenArray[second];
					givenArray[second]=temp;
				}

			}	

		}
		
		//System.out.println(givenArray);
		
			   //System.out.println("After sort the given array " +Arrays.toString(givenArray));
			   System.out.println("smallest number in the array "+ givenArray[0]);
			   System.out.println("Highest number in he array " +givenArray[(givenArray.length-1)]);
			   System.out.println("Second smallest number in the array "+ givenArray[1]);
			   System.out.println("Second Highest number in he array " +givenArray[(givenArray.length-2)]);
		  
		  


	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SmallestNumberInArray sortObj= new SmallestNumberInArray();
		sortObj.FindSmallestNoInArray();

	}

}
