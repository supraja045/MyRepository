package com.LearnAutomationOnline;

import java.util.Scanner;

//public class SwapTwoNumbers {
//
//	public void SwapUsingTempVariable()
//	{
//		@SuppressWarnings("resource")
//		Scanner input = new Scanner(System.in);
//		System.out.println("Enter the numbers to swap");
//		int mySal = input.nextInt();  // Read user input
//		int hisSal=  input.nextInt();
//		System.out.println("Before swap: "+"My Salary : "+mySal +" His Salary : "+hisSal);
//		int temp=0;
//		
//		//Logic of swap using temp variable
//		temp=mySal;
//		mySal=hisSal;
//		hisSal=temp;
//		
//		System.out.println("After swap: "+"My Salary : "+mySal +" His Salary : "+hisSal);	
//		
//	}
//	
//	
//	public void SwapUsingArithmeticOpn()
//	{
//		
//		Scanner input = new Scanner(System.in);
//		System.out.println("Enter the numbers to swap");
//		int first = input.nextInt();  // Read user input
//		int second=  input.nextInt();
//		System.out.println("Before swap: "+"My Salary : "+first +" His Salary : "+second);
//		
//		//logic of swapping in addition and subtraction
//		first= first-second;
//		second= first+second;
//		first= second-first;
//		
//		System.out.println("After swap: "+"My Salary : "+first +" His Salary : "+second);	
//		
//	}
//	public static void main(String[] args) {
//		
//		SwapTwoNumbers swapObj= new SwapTwoNumbers();
//		//swapObj.SwapUsingTempVariable();
//		swapObj.SwapUsingArithmeticOpn();
//		
//	}
	
//	class Scaler
//	{
//	   static int i;
//	   static
//	   {
//	       System.out.println("a");
//	       i = 100;
//	   }
//	}
//	public class StaticBlock
//	{
//	   static
//	   {
//	       System.out.println("b");
//	   }
//	   public static void main(String[] args)
//	   {
//	       System.out.println("c");
//	       System.out.println(Scaler.i);
//	   }
//	}

