package com.LearnAutomationOnline;

import java.util.Scanner;

public class ReverseANumber {
	
	
	public int reverseANumber()
	{
		int reversedNumber = 0;
		
		//Getting input
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the number to reverse");
		
		int givenNumber = input.nextInt();  // Read user input
		System.out.println("Number before reverse is: " + givenNumber); // Output user input

		//Logic
		while(givenNumber>0)
		{
		reversedNumber = reversedNumber*10;
		reversedNumber= reversedNumber+givenNumber%10;
		givenNumber=givenNumber/10;
		}
		
		//Printing the output
		System.out.println("Number after reverse is: " + reversedNumber);
		
		return 0;
		
	}
	
	//Main method
	public static void main(String[] args) {
		ReverseANumber reverseAno= new ReverseANumber();
		int no=reverseAno.reverseANumber();
	}

}
