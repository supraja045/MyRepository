package com.LearnAutomationOnline;

import java.util.Iterator;
import java.util.Scanner;

public class ReverseAString {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
/*	{
//		String reverseString = "";
//
//		Scanner input = new Scanner(System.in);
//		System.out.println("Enter the string to reverse");
//		
//		String string = input.nextLine();  // Read user input
//		System.out.println("String before reverse is: " + string);  // Output user input
//		"Supraja " --> [S,u,p,r,a,j,a] 0-6
//		char[] charArray=string.toCharArray();
//		
//		for(int i=(charArray.length-1);i>=0;i--)
//		{
 * 			a=j+a;
 * 			
 * 			
//			reverseString=reverseString+charArray[i];
//
//		}
 * 		reveresdString= ajarpuS;
//		
//		System.out.println("String after reverse: "+reverseString);
*///		
//	
	//"Supraja is my trainer" 
	//trainer my is Supraja
	
		String myString = "";
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the string to reverse");
		String string = input.nextLine();  // Read user input
		
		String[] mylist= string.split(" ");
		for (int i=mylist.length-1; i>=0;i--)
		{
			myString = myString +" "+ mylist[i];
			
		}
		System.out.println(myString.trim());
		}

}
