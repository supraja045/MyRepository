package com.LearnAutomationOnline;

public class PascalTraingle {

	/*
	Pascal's triangle.
	Example:
	Input: 5
	Output:
	[
	 [1],
	 [1,1],
	 [1,2,1],
	 [1,3,3,1],
	 [1,4,6,4,1]
	]
	 */
	public static void main(String[] args) {


		int limit=4;
		int startingNo=1;

		for(int row=0;row<=limit;row++)
		{
			System.out.print("[");
			for(int column=0;column<=row;column++)
			{
				
				System.out.print(startingNo+",");
				startingNo++;
			}
			System.out.print("],");
			System.out.println();
		}
	}
}