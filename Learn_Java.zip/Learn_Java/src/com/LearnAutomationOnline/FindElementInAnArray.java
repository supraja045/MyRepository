package com.LearnAutomationOnline;

public class FindElementInAnArray {

	public void FindingElementInAnArray()
	{

		int[] array = {3,4,5,6,7,7};
		int numberToFind= 17;
		boolean toFind=false;
		for(int i=0;i<array.length;i++)
		{
			if(numberToFind==array[i])
			{
				toFind=true;
				break;			
			}
			
		}
		if(toFind==true)
		{
			System.out.println("The number "+numberToFind + " is present inside the array");
		}
		else
		{
			
			System.out.println("The number is "+ numberToFind+ " not present");
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FindElementInAnArray findingObj = new FindElementInAnArray();
		findingObj.FindingElementInAnArray();

	}

}
