package com.LearnAutomationOnline;

import java.util.Arrays;

public class ReplaceVowelsWithASpecialCharacter 
{

	public void ReplaceVowelsWithASplCharacter()
	{
		String givenString = "MyString";
		String[] givenArray= givenString.split("");
		
		
		
		for (int i = 0; i < givenString.length(); i++) 
		{
			if(givenString.charAt(i)=='A' ||givenString.charAt(i)=='E' ||givenString.charAt(i)=='I' ||givenString.charAt(i)=='O' ||givenString.charAt(i)=='U' ||givenString.charAt(i)=='a' ||givenString.charAt(i)=='e' ||givenString.charAt(i)=='i' ||givenString.charAt(i)=='o' ||givenString.charAt(i)=='u')
			{
				givenArray[i]="*";
				
			}
		
		}
		String opString=Arrays.toString(givenArray);
		opString=opString.replace(",", "");
		opString=opString.replace("[", "");
		opString=opString.replace("]", "");
		opString=opString.replace(" ", "");
		System.out.println(opString);
		
	}


	public static void main(String[] args)
	{

		ReplaceVowelsWithASpecialCharacter myObj = new ReplaceVowelsWithASpecialCharacter();
		myObj.ReplaceVowelsWithASplCharacter();
	}

}
