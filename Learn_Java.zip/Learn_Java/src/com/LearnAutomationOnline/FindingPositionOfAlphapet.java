package com.LearnAutomationOnline;

import java.util.Scanner;

public class FindingPositionOfAlphapet {

	public void FindingPostion() 
	{

		Scanner scanner= new Scanner(System.in);

		System.out.println("Enter the character which you want to find the position ");
		String givenStr= scanner.nextLine();


		char[] ch  = givenStr.toCharArray();
		for(char c : ch)
		{
			int temp = (int)c;
			int temp_integer = 96; //for lower case
			if(temp<=122 & temp>=97)
				System.out.print(temp-temp_integer);
				
		}
		System.out.println();


		String str = "FGHI";
		System.out.println("the upper case character which you want to find the position "+str);
		char[] charArray  = str.toCharArray();
		for(char c : charArray){
			int temp = (int)c;
			int temp_integer = 64; //for upper case
			if(temp>=65 && temp<=90)
				System.out.print(temp-temp_integer);
		}
		
		System.out.println();
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FindingPositionOfAlphapet findingPosition= new FindingPositionOfAlphapet();
		findingPosition.FindingPostion();

	}

}
