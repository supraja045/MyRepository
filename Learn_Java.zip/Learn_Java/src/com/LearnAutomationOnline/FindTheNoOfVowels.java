package com.LearnAutomationOnline;

import java.util.Arrays;

public class FindTheNoOfVowels {

	public void FindingNoOfVowels()
	{
	
		String givenString = "Agniprasath";
		String[] givenArray = givenString.toLowerCase().split("");
		
		Arrays.sort(givenArray);
		String vowels = "aeiou";
		String[] vowelArray = vowels.toLowerCase().split("");
		
		Arrays.sort(vowelArray);
		

		int count = 0 ;
		for(String vowel:vowelArray)
		{
			for(String ch:givenArray)
			{
				if(ch.equals(vowel))
				{
					
					count=count+1;
				}
			}
			
		}
		System.out.println("Vowels count" +count);
		
		
	}
	
	public static void main(String[] args) 
	{
	
		FindTheNoOfVowels myObj = new FindTheNoOfVowels();
		myObj.FindingNoOfVowels();
	}
}
