package com.LearnAutomationOnline;

public class ExtractNosFromAString 
{

	public void ExtractNoFromAString()
	{
		String givenString = "prasath234";
		int digit=0;
		for(int i=0;i<givenString.length();i++)
		{
			
			 char character = givenString.charAt(i);              
             if (Character.isDigit(character))
             {
            	 digit=digit+Character.getNumericValue(character);
             }
                
		}
		System.out.println("Addition of the numbers present in the string is "+digit);
	}
	
	
	public void ExtractNoFromStringUsingRegex()
	{
		   String str="prasath234";
		   String numberOnly= str.replaceAll("[^0-9]", "");
		   String[] numberOnlyArray = numberOnly.split("");
		   int addition = 0;
		   for(int i =0;i<numberOnlyArray.length;i++)
		   {
			   int num =Integer.parseInt(numberOnlyArray[i]);
			   addition=addition+num;
		   }
		   
		   System.out.println(addition);
	}

	public static void main(String[] args)
	{
		ExtractNosFromAString myObj= new ExtractNosFromAString();
		//myObj.ExtractNoFromAString();
		myObj.ExtractNoFromStringUsingRegex();
	}
}
